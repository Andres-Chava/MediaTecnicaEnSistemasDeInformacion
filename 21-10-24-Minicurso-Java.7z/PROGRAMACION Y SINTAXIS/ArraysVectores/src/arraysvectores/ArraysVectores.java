package arraysvectores;
import java.util.Scanner;

public class ArraysVectores {

    public static void main(String[] args) {
        int vector [] = new int [4];
        Scanner teclado = new Scanner (System.in);
        
        for (int i=0; i<vector.length; i++){
            System.out.println("Ingrese el valor para el indice " + i);
            vector[i] = teclado.nextInt();
        }
        for (int i=0; i<vector.length; i++) {
           
            System.out.println("Estoy en el indice: " + i);
            System.out.println("Estoy guardando un: " + vector[i]);
            System.out.println("-------------------------");
        }
    }
    
}

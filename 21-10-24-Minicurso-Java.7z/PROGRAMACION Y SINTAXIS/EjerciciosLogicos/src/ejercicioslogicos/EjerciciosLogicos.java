package ejercicioslogicos;

public class EjerciciosLogicos {

    public static void main(String[] args) {
        int num1, num2, cambio;
        
        num1 = 1;
        num2 = 2;
        
        System.out.println("---ANTES---");
        System.out.println("Num1: " + num1);
        System.out.println("Num2: " + num2);
        
        cambio = num1;
        num1 = num2;
        num2 = cambio;
        
        System.out.println("---DESPUÉS---");
        System.out.println("Num1: " + num1);
        System.out.println("Num2: " + num2);
    }
    
}



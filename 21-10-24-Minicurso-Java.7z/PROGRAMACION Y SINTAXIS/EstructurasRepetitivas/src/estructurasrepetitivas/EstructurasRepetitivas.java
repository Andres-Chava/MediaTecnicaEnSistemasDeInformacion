package estructurasrepetitivas;

public class EstructurasRepetitivas {

    public static void main(String[] args) {
        
        /* --- WHILE ---
        int cont = 0;
        while (cont <= 10){
            
            System.out.println("Estoy en la vuelta: " + cont);
            cont = cont +1;
            
        }
        */
        
        /* --- FOR ---
        for (int cont = 0; cont <= 10; cont++){
            System.out.println("Estoy en la vuelta: " + cont);
        }
        */
    }
    
}

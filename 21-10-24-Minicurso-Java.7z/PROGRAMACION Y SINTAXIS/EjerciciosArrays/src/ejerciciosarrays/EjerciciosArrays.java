package ejerciciosarrays;
import java.util.Scanner;
public class EjerciciosArrays {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner (System.in);
        
        /* --- EJERCICIO #1 ---
        int vector [] = new int [15];
        int cont = 0;
        
        for (int i = 0; i<15; i++){
            System.out.println("Ingrese el valor del vector: ");
            vector [i] = teclado.nextInt();
            if (vector[i] == 3){
                cont++;
            }
        }
        
        System.out.println("Se encontraron " + cont + " números 3."); */
        
        double matriz[][] = new double [4][4];
        double suma = 0.0;
        
        for (int f=0; f<4; f++){
            for (int c=0; c<3; c++){
                System.out.println("Ingrese la calificación del alumno n° " + f + ":");
                matriz [f][c] = teclado.nextDouble();
                
                suma = suma + matriz[f][c];
            }
            matriz[f][3] = suma/3;
            suma = 0.0;
        }
        
        for (int f=0; f<4; f++){
            System.out.println("Las notas del alumno n° " + f + " son: ");
            for (int c=0; c<3; c++){
                System.out.println("Nota N° " + c + " " + matriz[f][c]);
            }
            System.out.println("El promedio de las notas es: " + matriz[f][3]);
            
            System.out.println("--------------------------");
        }
    }
}

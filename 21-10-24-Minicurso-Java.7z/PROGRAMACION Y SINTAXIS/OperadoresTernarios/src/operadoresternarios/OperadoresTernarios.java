package operadoresternarios;
import java.util.Scanner;

public class OperadoresTernarios {
    
    public static void main(String[] args) {
    String condicionFinal;
    double promedio;
    Scanner teclado = new Scanner (System.in);
    
    System.out.println("Ingrese el promedio general del alumno: ");
    promedio = teclado.nextDouble();
    
    condicionFinal = promedio >=6 ? "Aprobado" : "Desaprobado";
        System.out.println("La condición final del alumno es: " + condicionFinal);
    }
    
}

package condicionalifelse;

public class CondicionalIfElse {

    public static void main(String[] args) {
    int num1 = 10;
    int num2 = 5;
    
    if  (num1 < num2) {
        System.out.println("El número 2 es mayor que el número 1");
    }
    else if (num1 == num2){
        System.out.println("Los números son iguales.");
    }
    else {
        System.out.println("El número 1 es mayor que el número 2");    
    }
    }
}